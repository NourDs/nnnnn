import 'package:flutter/material.dart';

class MyColors{
  static const Color primary = Color(0xFF7FAFFF);
  static const Color primary100 = Color(0xCC008FD4);
  static const Color primary200 = Color(0x99008FD4);
  static const Color primary300 = Color(0x66008FD4);
  static const Color primary400 = Color(0x33008FD4);

}