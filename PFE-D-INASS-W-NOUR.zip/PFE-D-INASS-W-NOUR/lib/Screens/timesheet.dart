import 'package:cell_calendar/cell_calendar.dart';
import 'package:flutter/material.dart';

class timesheet extends StatefulWidget {
  @override
  State<timesheet> createState() => _timesheetState();
}

class _timesheetState extends State<timesheet> {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'something',),
    );
  }
}

class MyHomePage extends StatefulWidget {
  static const routeName = '/successful_screen';
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String? dropdownValue;

  @override
  Widget build(BuildContext context) {
    final _sampleEvents = sampleEvents;
    final cellCalendarPageController = CellCalendarPageController();
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        automaticallyImplyLeading : true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () { Navigator.pop(context); },
        ),
      ),
      floatingActionButton:FloatingActionButton.extended(
        onPressed: () {},
        icon: Icon(Icons.save),
        label: Text("Save"),
      ),
      body: Column(
        children: [
          Expanded(
            flex: 9,
            child: CellCalendar(
              cellCalendarPageController: cellCalendarPageController,
              events: sampleEvents,
              daysOfTheWeekBuilder: (dayIndex) {
                final labels = ["S", "M", "T", "W", "T", "F", "S"];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 4.0),
                  child: Text(
                    labels[dayIndex],
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                );
              },
              monthYearLabelBuilder: (datetime) {
                final year = datetime?.year.toString();
                final month = datetime?.month.monthName;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      const SizedBox(width: 16),
                      Text(
                        "$month  $year",
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        padding: EdgeInsets.zero,
                        icon: Icon(Icons.calendar_today),
                        onPressed: () {
                          cellCalendarPageController.animateToDate(
                            DateTime.now(),
                            curve: Curves.linear,
                            duration: Duration(milliseconds: 300),
                          );
                        },
                      )
                    ],
                  ),
                );
              },
              onCellTapped: (date) {
                final eventsOnTheDate = _sampleEvents.where((event) {
                  final eventDate = event.eventDate;
                  return eventDate.year == date.year &&
                      eventDate.month == date.month &&
                      eventDate.day == date.day;
                }).toList();
                showDialog(
                    context: context,
                    builder: (BuildContext context) => AlertDialog(
                      title:
                      Text(date.month.monthName + " " + date.day.toString()),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        children:[
                          DropdownButtonFormField(
                            icon: Icon(Icons.arrow_drop_down),
                            items: const [
                              DropdownMenuItem(child: Text("0"),value: "0",),
                              DropdownMenuItem(child: Text("0.5"),value: "0.5",),
                              DropdownMenuItem(child: Text("1"),value: "1",),
                            ],
                            onChanged: (String? selectedValue)
                            {
                                print(dropdownValue);
                                setState(() {
                                  dropdownValue = selectedValue;
                                });
                              },
                          ),
                        ]
                      ),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () {
                            bool isActive = true ;
                            setState(() {
                              sampleEvents.forEach((e) {
                                if(e.eventDate == date ){
                                  isActive = false;
                                }
                              });
                              if(isActive) {
                                sampleEvents.add(
                                  CalendarEvent(
                                      eventName: "$dropdownValue",
                                      eventDate: date,
                                      eventBackgroundColor: Colors.purple),
                                );
                              }
                              else{
                                sampleEvents.forEach((element) {
                                if (element.eventDate == date){
                                  sampleEvents.remove(element);
                                }
                              });
                              sampleEvents.add(
                                CalendarEvent(
                                    eventName: "$dropdownValue",
                                    eventDate: date,
                                    eventBackgroundColor: Colors.purple),
                              );}
                              Navigator.pop(context, "Submit");
                            });
                          },
                          child: Text("Submit"),
                        ),
                      ],
                    ));
              },
              onPageChanged: (firstDate, lastDate) {
                /// Called when the page was changed
                /// Fetch additional events by using the range between [firstDate] and [lastDate] if you want
              },
            ),
          ),
          Expanded(
            flex: 1,
            child: Text('')
          )

        ],
      ),
    );
  }
}

List<CalendarEvent> sampleEvents = [
  ];