import 'package:app/Screens/Employe/mainPage.dart';
import 'package:app/main.dart';
import 'package:flutter/material.dart';
import '../Constants/colors.dart';
import 'login_screen.dart';
import 'dart:async';

class WelcomeScreen extends StatefulWidget {

  static const routeName = '/welcome-screen';

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Timer(
      Duration(seconds: 3),
      () => Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen())),
      );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Drawing Paths',
            home: Container(
              color: Colors.transparent,
              child: CustomPaint(
                painter: UpperCurvePainter(),
              ),
            ),
          ),
          MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Drawing Paths',
            home: Container(
              color: Colors.transparent,
              child: CustomPaint(
                painter: CurvePainter(),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 6,
                child: Padding(
                  padding: const EdgeInsets.only(top: 60, left: 25),
                  child: Center(
                    child: Column(
                      children: [
                        SizedBox(height: MediaQuery.of(context).size.height*0.25,),
                        Image.asset('Asset/KYTL.png'),
                        //Text('KYTL', style: TextStyle(fontSize: 55, fontWeight: FontWeight.bold, color: Colors.black),),
                        const Text('Your trusted cyber security partner',
                          style: TextStyle(
                              fontSize: 18,
                              fontStyle:
                              FontStyle.italic,
                              color: MyColors.primary100
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                flex: 3,
                child: Column(
                  children: [
                    Container(
                      color: Colors.transparent,
                      height: 80,
                      width: double.infinity,
                      padding: const EdgeInsets.only(top: 25, left: 24, right: 24),
                    ),
                  ],
                ),
              ),
              CustomPaint(
                painter: CurvePainter(),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
class CurvePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint();
    paint.color = MyColors.primary;
    paint.style = PaintingStyle.fill;

    var path = Path();

    path.moveTo(0, size.height * 0.9167);
    path.quadraticBezierTo(size.width * 0.25, size.height * 0.875,
        size.width * 0.5, size.height * 0.9167);
    path.quadraticBezierTo(size.width * 0.75, size.height * 0.9584,
        size.width * 1.0, size.height * 0.9167);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}

class UpperCurvePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint();
    paint.color = MyColors.primary;
    paint.style = PaintingStyle.fill; // Change this to fill

    var path = Path();

    path.moveTo(0,size.height*0.05);
    path.quadraticBezierTo(
        size.width*2/3, size.height*0.1, size.width, size.height * 0.2);
    path.lineTo(size.width, 0);
    path.lineTo(0, 0);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}