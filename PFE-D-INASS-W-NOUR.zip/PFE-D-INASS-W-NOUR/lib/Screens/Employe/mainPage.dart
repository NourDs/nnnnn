import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as intl;
import 'package:timer_builder/timer_builder.dart';
import '../../Constants/colors.dart';
import '../timesheet.dart';



class mainPage extends StatefulWidget {
  const mainPage({Key? key}) : super(key: key);

  @override
  State<mainPage> createState() => _mainPageState();
}

class _mainPageState extends State<mainPage> {

  List months =
  ['jan', 'feb', 'mar', 'apr', 'may','jun','jul','aug','sep','oct','nov','dec'];


  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(MediaQuery.of(context).size.height*0.2),
            child: AppBar(
              automaticallyImplyLeading: false,
              flexibleSpace: Container(
                decoration:
                const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage("Asset/HelloM.png"),
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            ),
          ),
          floatingActionButton: const CircleAvatar(
            radius: 60,
            backgroundImage: AssetImage("Asset/profile1.png"),
          ),
          floatingActionButtonLocation: FloatingActionButtonLocation.startTop,
          body: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(0,8,60,8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children:  [
                    Column(
                      children: const [
                        Text(
                          "Yassmin Boumedian",
                          style: TextStyle(
                            fontWeight: FontWeight.bold
                          ),
                        ),
                        Text("Responsable Consultant",),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height*0.02,),
              TimerBuilder.periodic(const Duration(minutes: 1), builder: (context)  {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        intl.DateFormat.jm().add_yMd().format(DateTime.now()),
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 17,
                        ),
                      ),
                    ),
                  ],
                );
              } ),
              SizedBox(
                height: MediaQuery.of(context).size.height*0.4,
                child: ListView(
                  children: [
                    buildContainer(intl.DateFormat.MMM().format(DateTime.now().subtract(Duration(days: 30)),)),
                    buildContainer(intl.DateFormat.MMM().format(DateTime.now())),
                    buildContainer(intl.DateFormat.MMM().format(DateTime.now().add(Duration(days: 30)))),
                  ],
                )
              )
            ],
          ),
        ),
    );
  }

  Container buildContainer(String month) {
    return Container(
                      color: Colors.transparent,
                      height: 80,
                      width: double.infinity,
                      padding: const EdgeInsets.only(top: 25, left: 24, right: 24),
                      child: RaisedButton(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => timesheet()),
                        ),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        color: MyColors.primary,
                        child:  Text(
                          month,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,),
                        ),
                      ),
                    );
  }
}
