import 'package:app/Manager/managerProfile.dart';
import 'package:app/Screens/Employe/mainPage.dart';
import 'package:flutter/material.dart';
import '../Constants/colors.dart';
import '../Models/auth.dart';
import 'timesheet.dart';

class LoginScreen extends StatelessWidget {

  static const routeName = '/login-screen';

  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  Widget userInput(TextEditingController userInput, String hintTitle, TextInputType keyboardType) {
    return Container(
      height: 55,
      margin: const EdgeInsets.only(bottom: 15),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          border:  Border.all(
              color: MyColors.primary
          )
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 25.0, top: 15, right: 25),
        child: TextField(
          controller: userInput,
          autocorrect: false,
          enableSuggestions: false,
          autofocus: false,
          decoration: InputDecoration.collapsed(
            hintText: hintTitle,
            hintStyle: const TextStyle(fontSize: 18, color: Colors.blueGrey, fontStyle: FontStyle.italic),
          ),
          keyboardType: keyboardType,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Drawing Paths',
            home: Container(
              color: Colors.white,
              child: CustomPaint(
                painter: UpperCurvePainter(),
              ),
            ),
          ),
          Container(
          /*decoration: const BoxDecoration(
            image: DecorationImage(
              alignment: Alignment.topCenter,
              fit: BoxFit.fill,
              image: AssetImage('Asset/up2.jpg'),
            ),
          ),*/
          color: MyColors.primary400,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(height: 10,),
              Image.asset('Asset/KYTL.png'),
              Container(
                height: MediaQuery.of(context).size.height*0.5,
                width: double.infinity,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(15), topRight: Radius.circular(15)),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 45),
                      userInput(emailController, 'Email', TextInputType.emailAddress),
                      userInput(passwordController, 'Password', TextInputType.visiblePassword),
                      Expanded(
                        flex: 3,
                        child: Column(
                          children: [
                            Container(
                              color: Colors.transparent,
                              height: 80,
                              width: double.infinity,
                              padding: const EdgeInsets.only(top: 25, left: 24, right: 24),
                              child: RaisedButton(
                                onPressed: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => MyApp()),
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(25),
                                ),
                                color: MyColors.primary,
                                child: const Text(
                                  'Log In',
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        ]
      ),
    );
  }
}


class UpperCurvePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint();
    paint.color = MyColors.primary;
    paint.style = PaintingStyle.fill;

    var path = Path();

    path.moveTo(0, size.height * 0.06);
    path.quadraticBezierTo(size.width * 0.25, size.height * 0.1,
        size.width * 0.5, size.height * 0.1);
    path.quadraticBezierTo(size.width * 0.75, size.height * 0.1,
        size.width * 1, size.height * 0.13);
    path.lineTo(size.width, 0);
    path.lineTo(0, 0);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}