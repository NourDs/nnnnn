import 'package:app/Constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import 'feedback.dart';

class NavDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
      child: ListView(
        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
        children: <Widget>[
          Stack(
              children: [

                Container(
                  child: Column(
                    children: [
                      SizedBox(height: MediaQuery.of(context).size.height*0.1,),
                      Text("Hello Yassmin"),
                      ElevatedButton(onPressed: (){}, child: Text("Edit Profile"),)
                    ],
                  ),
                  margin: EdgeInsets.fromLTRB(5, 40, 5, 40),
                  width: 390,
                  height: 150,decoration: BoxDecoration(
                  color: MyColors.primary,
                  borderRadius: BorderRadius.circular(18.0),


                ),),
                Align(
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      child: CircleAvatar(
                        radius: 40.0,
                        backgroundColor: Colors.white,
                        child: CircleAvatar(
                          child: Align(
                            alignment: Alignment.bottomRight,
                            child: CircleAvatar(
                              backgroundColor: Colors.white,
                              radius: 12.0,
                              child: Icon(
                                Icons.camera_alt,
                                size: 15.0,
                                color: Color(0xFF404040),
                              ),
                            ),
                          ),
                          radius: 38.0,
                          backgroundImage: AssetImage(
                              'Asset/up.jpg'),
                        ),
                      ),)
                ),

              ]
          ),
          /*Container(
            color: MyColors.primary,
            height:  MediaQuery.of(context).size.height*0.25,
            child: CircleAvatar(

            ),

          ),
          CircleAvatar(
            radius: 40,
            backgroundImage:AssetImage("Asset/up.jpg"),
          ),*/
          SizedBox(height: MediaQuery.of(context).size.height*0.05,),
          ListTile(
            leading: Icon(Icons.input),
            title: Text('Welcome'),
            onTap: () => {},
          ),
          SizedBox(height: MediaQuery.of(context).size.height*0.05,),
          ListTile(
            leading: Icon(Icons.verified_user),
            title: Text('Profile'),
            onTap: () => {Navigator.of(context).pop()},
          ),
          SizedBox(height: MediaQuery.of(context).size.height*0.05,),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('Settings'),
            onTap: () => {Navigator.of(context).pop()},
          ),
          SizedBox(height: MediaQuery.of(context).size.height*0.05,),
          ListTile(
            leading: Icon(Icons.border_color),
            title: Text('Feedback'),
            onTap: () => {Navigator.of(context).push(
              MaterialPageRoute(builder: (context) => App()),
            )},
          ),
          SizedBox(height: MediaQuery.of(context).size.height*0.05,),
          ListTile(
            leading: Icon(Icons.exit_to_app),
            title: Text('Logout'),
            onTap: () => {Navigator.of(context).pop()},
          ),
        ],
      ),
    );
  }
}