import 'dart:async';
import 'package:app/Manager/widget.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as intl;
import 'package:timer_builder/timer_builder.dart';
import '../../Constants/colors.dart';
import '../Screens/timesheet.dart';



class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  List months =
  ['jan', 'feb', 'mar', 'apr', 'may','jun','jul','aug','sep','oct','nov','dec'];


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: MyColors.primary,
          shadowColor: Colors.transparent,
          title: Text('KYTL'),
        ),
        drawer: NavDrawer(),
        body: Stack(
          children: [
            MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'Drawing Paths',
              home: Container(
                color: Colors.transparent,
                child: CustomPaint(
                  painter: UpperCurvePainter(),
                ),
              ),
            ),
            MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'Drawing Paths',
              home: Container(
                color: Colors.transparent,
                child: CustomPaint(
                  painter: CurvePainter(),
                ),
              ),
            ),
              Column(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0,8,60,8),
                  ),
                  SizedBox(height: MediaQuery.of(context).size.height*0.15,),
                  SizedBox(
                      height: MediaQuery.of(context).size.height*0.4,
                      child: ListView(
                        children: [
                          buildContainer(intl.DateFormat.MMM().format(DateTime.now().subtract(Duration(days: 30)),)),
                          buildContainer(intl.DateFormat.MMM().format(DateTime.now())),
                          buildContainer(intl.DateFormat.MMM().format(DateTime.now().add(Duration(days: 30)))),
                        ],
                      )
                  )
                ],
              ),
          ]
        ),
      ),
    );
  }

  Container buildContainer(String month) {
    return Container(
      color: Colors.transparent,
      height: 80,
      width: double.infinity,
      padding: const EdgeInsets.only(top: 25, left: 24, right: 24),
      child: RaisedButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => timesheet()),
        ),
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
        color: MyColors.primary,
        child:  Text(
          month,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w700,
            color: Colors.white,),
        ),
      ),
    );
  }
}

class CurvePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint();
    paint.color = MyColors.primary;
    paint.style = PaintingStyle.fill;

    var path = Path();

    path.moveTo(0, size.height * 0.9167);
    path.quadraticBezierTo(size.width * 0.25, size.height * 0.875,
        size.width * 0.5, size.height * 0.9167);
    path.quadraticBezierTo(size.width * 0.75, size.height * 0.9584,
        size.width * 1.0, size.height * 0.9167);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}






        /*MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Drawing Paths',
        home: Container(
          color: Colors.transparent,
          child: CustomPaint(
            painter: UpperCurvePainter(),
          ),
        ),
      ),*/
      /*MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Drawing Paths',
        home: Container(
          color: Colors.transparent,
          child: CustomPaint(
            painter: CurvePainter(),
          ),
        ),
      ),*/

class UpperCurvePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint();
    paint.color = MyColors.primary;
    paint.style = PaintingStyle.fill; // Change this to fill

    var path = Path();

    path.moveTo(0,size.height*0.05);
    path.quadraticBezierTo(
        size.width*2/3, size.height*0.1, size.width, size.height * 0.2);
    path.lineTo(size.width, 0);
    path.lineTo(0, 0);

    canvas.drawPath(path, paint);
  }
  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}

